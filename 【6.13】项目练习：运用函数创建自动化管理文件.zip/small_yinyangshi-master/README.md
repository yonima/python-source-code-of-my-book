# small_yinyangshi
简化版本阴阳师：自我游戏人物以及场景设计，不同的游戏人物在游戏场景中有不同的表现：失败还是成功。如果失败则回城，恢复体力。否则接着战斗
共包括3个文件：
1. 游戏主程序文件 main_yinyangshi.py
2. 游戏选择文件 game_select.py
3. 游戏人物设计文件  yinyangshi.py
